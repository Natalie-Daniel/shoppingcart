<?php session_start();

$hashed_pwd = '$2y$10$BMcKSABQyyciPbUWl.pE9.6zv1tbk.O0QXlX/NMLxWt7vLxOCx/h.';

// TODO: PHP Form Validation (see the example under Validate Form Data With PHP)

?>
<!DOCTYPE html>
<html>
    <body>
        Invalid username and/or password.

        <a href="index.php">Homepage</a>
    </body>
</html>
